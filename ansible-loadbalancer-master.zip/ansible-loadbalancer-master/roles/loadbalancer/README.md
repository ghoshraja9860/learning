LoadBalancer
============

Ansible Role to configure HAProxy LoadBalancer

Requirements
------------

No Such Requirements

Role Variables
--------------

No Variables Included

Dependencies
------------

No Dependencies on other roles or collections

Example Playbook
----------------

    - hosts: servers
      roles:
         - loadbalancer

License
-------

BSD

Author Information
------------------

Author Name: Aman Jhagrolia  
Contact: https://www.linkedin.com/in/amanjhagrolia143  
