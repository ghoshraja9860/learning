WebServer
=========

Ansible Role to configure Apache HTTPD Webserver

Requirements
------------

No Such Requirements

Role Variables
--------------

No Variables Included

Dependencies
------------

No Dependencies on other roles or collections

Example Playbook
----------------

    - hosts: servers
      roles:
         - webserver

License
-------

BSD

Author Information
------------------

Author Name: Aman Jhagrolia  
Contact: https://www.linkedin.com/in/amanjhagrolia143  
